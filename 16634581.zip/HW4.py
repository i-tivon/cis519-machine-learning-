#!/usr/bin/env python
# coding: utf-8

# In[12]:


import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.autograd import Variable
from torchvision import transforms
# import matplotlib as mpl
# import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
#from google.colab import drive                IF you are using COLAB
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


# In[13]:


# Use this if you are working on COLAB
# This will prompt for authorization.
#drive.mount('/content/drive')


# In[14]:


def extract_data(x_data_filepath, y_data_filepath):
    X = np.load(x_data_filepath)
    y = np.load(y_data_filepath)
    return X, y
#train, label = extract_data("images_train.npy", "labels_train.npy")


# In[15]:



# train.shape, label.shape, type(train)
# # plt.imshow(train[1].T)


# In[16]:


def data_visualization(images,labels):
    """
    Visualize 6 pictures per class using your prefered visulization library (matplotlib, etc)

    Args:
        images: training images in shape (num_images,3,image_H,image_W)
        labels: training labels in shape (num_images,)
    """
    for i in range (0, 5):
        a = np.where(label == i)
        count = 0
        print('Class #{}'.format(i+1))
        for j in a[0]:
            print('picture #{}'.format(count+1))
            plt.imshow(images[j].T)
            plt.pause(0.5)
            count+=1
            if count == 6:
                break;


    

# data_visualization(train, label)


# In[17]:


############################################################
# Extracting and loading data
############################################################
class Dataset(Dataset):
    def __init__(self, X, y):
        self.len = len(X)           
        if torch.cuda.is_available():
          self.x_data = torch.from_numpy(X).float().cuda()
          self.y_data = torch.from_numpy(y).long().cuda()
        else:
          self.x_data = torch.from_numpy(X).float()
          self.y_data = torch.from_numpy(y).long()
    
    def __len__(self):
        return self.len

    def __getitem__(self, idx):
        return self.x_data[idx], self.y_data[idx]


# In[18]:


def create_validation(x_train,y_train):
    """
    Randomly choose 20 percent of the training data as validation data.

    Args:
        x_train: training images in shape (num_images,3,image_H,image_W)
        y_train: training labels in shape (num_images,)
    Returns:
        new_x_train: training images in shape (0.8*num_images,3,image_H,image_W)
        new_y_train: training labels in shape (0.8*num_images,)
        x_val: validation images in shape (0.2*num_images,3,image_H,image_W)
        y_val: validation labels in shape (0.2*num_images,)
    """
    new_x_train, x_val, new_y_train, y_val = train_test_split(x_train, y_train, test_size=0.2)
    return new_x_train,new_y_train,x_val,y_val
#new_x_train,new_y_train,x_val,y_val = create_validation(train, label)
# new_x_train.shape ,new_y_train.shape ,x_val.shape ,y_val.shape
  
  
  


# In[19]:


############################################################
# Feed Forward Neural Network
############################################################
class FeedForwardNN(nn.Module):
    """ 
        (1) Use self.fc1 as the variable name for your first fully connected layer
        (2) Use self.fc2 as the variable name for your second fully connected layer
    """
    def __init__(self):
        super(FeedForwardNN, self).__init__()
        self.fc1 = nn.Linear(16320, 2000)
        self.fc2 = nn.Linear(2000, 5)

    def forward(self, x):
        x = x.view(-1, 16320)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

    """ 
        Please do not change the functions below. 
        They will be used to test the correctness of your implementation 
    """
    def get_fc1_params(self):
        return self.fc1.__repr__()
    
    def get_fc2_params(self):
        return self.fc2.__repr__()


# In[20]:


############################################################
# Convolutional Neural Network
############################################################
class ConvolutionalNN(nn.Module):
    """ 
        (1) Use self.conv1 as the variable name for your first convolutional layer
        (2) Use self.pool1 as the variable name for your first pooling layer
        (3) Use self.conv2 as the variable name for your second convolutional layer
        (4) Use self.pool2 as the variable name for you second pooling layer  
        (5) Use self.fc1 as the variable name for your first fully connected laye
        (6) Use self.fc2 as the variable name for your second fully connected layer
    """
    def __init__(self):
        super(ConvolutionalNN, self).__init__()
        #(3,64,85)
        self.conv1 = nn.Conv2d(3, 16, kernel_size=3, stride=1, padding=0)
        #(16,62,83)
        self.pool1 = nn.MaxPool2d(kernel_size=2)
        #(16,31,41)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=0)
        #(32,29,39)
        self.pool2 = nn.MaxPool2d(kernel_size=2)
        #(32,14,19)
        #self.drop_out = nn.Dropout()
        self.fc1 = nn.Linear(32*14*19, 200)
        self.fc2 = nn.Linear(200, 5)
      
    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = self.pool1(x)
        x = F.relu(self.conv2(x))
        x = self.pool2(x)
        x = x.view(-1, 32*14*19)
        #x = self.drop_out(x)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        
        return x
      
    """ 
        Please do not change the functions below. 
        They will be used to test the correctness of your implementation
    """
    
    def get_conv1_params(self):
        return self.conv1.__repr__()
    
    def get_pool1_params(self):
        return self.pool1.__repr__()

    def get_conv2_params(self):
        return self.conv2.__repr__()
      
    def get_pool2_params(self):
        return self.pool2.__repr__()
      
    def get_fc1_params(self):
        return self.fc1.__repr__()
    
    def get_fc2_params(self):
        return self.fc2.__repr__()


# In[21]:


def normalize_image(image):
    """
    Normalize each input image

    Args:
        image: the input image in shape (3,image_H,image_W)
    Returns:
        norimg: the normalized image in the same shape as the input
    """
    l,w,h = image.shape
    R = image[0].reshape(-1, w*h)
    R = (R-R.mean())/R.std()
    image[0] = R.reshape(w,h)
    G = image[1].reshape(-1, w*h)
    G = (G-G.mean())/G.std()
    image[1] = G.reshape(w,h)
    B = image[2].reshape(-1, w*h)
    B = (B-B.mean())/B.std()
    image[2] = B.reshape(w,h)
    return image


# In[22]:


############################################################
# Optimized Neural Network
############################################################
class OptimizedNN(nn.Module):
    def __init__(self):
        super(OptimizedNN, self).__init__()
        #(3,64,85)
        self.conv1 = nn.Conv2d(3, 16, kernel_size=3, stride=1, padding=0)
        #(16,62,83)
        self.pool1 = nn.MaxPool2d(kernel_size=2)
        #(16,31,41)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=0)
        #(32,29,39)
        self.pool2 = nn.MaxPool2d(kernel_size=2)
        #(32,14,19)
        self.drop_out = nn.Dropout()
        self.fc1 = nn.Linear(32*14*19, 200)
        self.fc2 = nn.Linear(200, 5)
      
    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = self.pool1(x)
        x = F.relu(self.conv2(x))
        x = self.pool2(x)
        x = x.view(-1, 32*14*19)
        x = self.drop_out(x)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        
        return x
      


# In[ ]:


def train_val_NN(neural_network, train_loader, validation_loader, loss_function, optimizer,num_epochs):
    """
    Runs experiment on the model neural network given a train loader, loss function and optimizer and find validation accuracy for each epoch given the validation_loader.

    Args:
        neural_network (NN model that extends torch.nn.Module): For example, it should take an instance of either
                                                                FeedForwardNN or ConvolutionalNN,
        train_loader (DataLoader),
        validation_loader (DataLoader),
        loss_function (torch.nn.CrossEntropyLoss),
        optimizer (optim.SGD)
        num_epochs (number of iterations)
    Returns:
        tuple: First position, training accuracies of each epoch formatted in an array of shape (num_epochs,1).
               Second position, training loss of each epoch formatted in an array of shape (num_epochs,1).
               third position, validation accuracy of each epoch formatted in an array of shape (num_epochs,1).

    """
    loss_total = []
    loss_totalval = []
    acctrain = []
    accval = []
    for epoch in range(num_epochs):  # loop over the dataset multiple times
        running_loss = 0.0
        running_lossval = 0.0
        correct = 0
        cval = 0
        total = 0
        tval = 0
        for i, data in enumerate(train_loader, 0):
            # get the inputs
            inputs, labels = data
            #inputs = inputs.reshape(-1, 16320).to(device)
            inputs = inputs.to(device)
            labels = labels.to(device)

            # zero the parameter gradients
            optimizer.zero_grad()

            # forward + backward + optimize
            outputs = neural_network(inputs)
            loss = loss_function(outputs, labels)
            loss.backward()
            optimizer.step()

            # print statistics
            running_loss += loss.item()
            #normalize loss
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
        loss_total.append(running_loss/len(train_loader))
        
        acctrain.append(100.0*correct / total)
        
        #validation data accuracy analysis
        for v, datav in enumerate(validation_loader, 0):
            # get the inputs
            inputsv, labelsv = datav
            #inputs = inputs.reshape(-1, 16320).to(device)
            inputsv = inputsv.to(device)
            labelsv = labelsv.to(device)

            # zero the parameter gradients
            optimizer.zero_grad()

            # forward + backward + optimize
            outputsv = neural_network(inputsv)
            lossval = loss_function(outputsv, labelsv)
            lossval.backward()
            optimizer.step()

            # print statistics
            running_lossval += lossval.item()
            _, predictedv = torch.max(outputsv.data, 1)
            tval += labelsv.size(0)
            cval += (predictedv == labelsv).sum().item()
        
        loss_totalval.append(running_lossval/len(validation_loader))
        accval.append(100.0*cval / tval)
        
        

    return acctrain, loss_total, accval, loss_totalval

  
#     return accuracy,loss_np,val_accuracy


# In[36]:


# #model = FeedForwardNN().to(device)
# model = OptimizedNN().to(device)
# train_dataset = Dataset(new_x_train,new_y_train)
# val_dataset = Dataset(x_val,y_val)
# train_loader = torch.utils.data.DataLoader(dataset=train_dataset, 
#                                            batch_size=64, 
#                                            shuffle=True)

# validation_loader = torch.utils.data.DataLoader(dataset=val_dataset, 
#                                           batch_size=64, 
#                                           shuffle=False)
# loss_function = nn.CrossEntropyLoss()
# optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
# #acctrain, loss_total, accval, loss_totalval= train_val_NN(model, train_loader, validation_loader, loss_function, optimizer,40)
# acctrain, loss_total, accval, loss_totalval= train_val_NN_normal(model, train_loader, validation_loader, loss_function, optimizer,40)
# accval[39]


# In[35]:


# import matplotlib as mpl
# import matplotlib.pyplot as plt
# plt.plot(loss_total, label='training')
# plt.plot(loss_totalval, label = 'validation')
# plt.title('experiment 4: training loss')
# plt.grid(True)
# plt.ylabel('loss')
# plt.xlabel('epochs')
# plt.legend()


# In[37]:


# def train_val_NN_normal(neural_network, train_loader, validation_loader, loss_function, optimizer,num_epochs):
#     """
#     normalized image
#     """
#     loss_total = []
#     loss_totalval = []
#     acctrain = []
#     accval = []
#     for epoch in range(num_epochs):  # loop over the dataset multiple times
#         running_loss = 0.0
#         running_lossval = 0.0
#         correct = 0
#         cval = 0
#         total = 0
#         tval = 0
#         for i, data in enumerate(train_loader, 0):
#             # get the inputs
#             inputs, labels = data
#             for p in range(len(inputs)):
#                 inputs[p] = normalize_image(inputs[p])
#             #inputs = inputs.reshape(-1, 16320).to(device)
#             inputs = inputs.to(device)
#             labels = labels.to(device)

#             # zero the parameter gradients
#             optimizer.zero_grad()

#             # forward + backward + optimize
#             outputs = neural_network(inputs)
#             loss = loss_function(outputs, labels)
#             loss.backward()
#             optimizer.step()

#             # print statistics
#             running_loss += loss.item()
#             _, predicted = torch.max(outputs.data, 1)
#             total += labels.size(0)
#             correct += (predicted == labels).sum().item()
#         loss_total.append(running_loss/len(train_loader))
        
#         acctrain.append(100.0*correct / total)
        
#         #validation data accuracy analysis
#         for v, datav in enumerate(validation_loader, 0):
#             # get the inputs
#             inputsv, labelsv = datav
#             for p in range(len(inputsv)):
#                 inputsv[p] = normalize_image(inputsv[p])
#             #inputs = inputs.reshape(-1, 16320).to(device)
#             inputsv = inputsv.to(device)
#             labelsv = labelsv.to(device)

#             # zero the parameter gradients
#             optimizer.zero_grad()

#             # forward + backward + optimize
#             outputsv = neural_network(inputsv)
#             lossval = loss_function(outputsv, labelsv)
#             lossval.backward()
#             optimizer.step()

#             # print statistics
#             running_lossval += lossval.item()
#             _, predictedv = torch.max(outputsv.data, 1)
#             tval += labelsv.size(0)
#             cval += (predictedv == labelsv).sum().item()
        
#         loss_totalval.append(running_lossval/len(validation_loader))
#         accval.append(100.0*cval / tval)
        
        

#     return acctrain, loss_total, accval, loss_totalval



# In[38]:


# plt.plot(loss_total, label='training')
# plt.plot(loss_totalval, label = 'validation')
# plt.title('experiment 4: loss')
# plt.grid(True)
# plt.ylabel('loss')
# plt.xlabel('epochs')
# plt.legend()


# In[39]:


# accval[39],accval_norm[39]


# In[34]:


def test_NN(neural_network, test_loader, loss_function):
  
    """
    Runs experiment on the model neural network given a test loader, loss function and optimizer.

    Args:
        neural_network (NN model that extends torch.nn.Module): For example, it should take an instance of either
                                                                FeedForwardNN or ConvolutionalNN,
        test_loader (DataLoader), (make sure the loader is not shuffled)
        loss_function (torch.nn.CrossEntropyLoss),
        optimizer (your choice)
        num_epochs (number of iterations)
    Returns:
        your predictions         
    """
    with torch.no_grad():
        Preds = []
        for images, _ in test_loader:
            images = images.to(device)
            for p in range(len(images)):
                 images[p] = normalize_image(images[p])
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            p = predicted.numpy()
            Preds = np.concatenate([Preds,p])
    return Preds
    

# result = test_NN(model, test_loader, loss_function)
# result=result.astype(int)
# np.savetxt("HW4_preds.txt", result, fmt="%s")


# In[ ]:


# Run Baseline FeedForward


# In[ ]:


# Run Baseline CNN


# In[ ]:


# Run Baseline CNN on Normilized Images


# In[30]:


# train, label = extract_data("images_train.npy", "labels_train.npy")
# test, _= extract_data("images_test.npy", "labels_train.npy")
# train_total_dataset = Dataset(train, label)

# #make fake labels 651,-
# fake_labels = np.random.random_integers(0,4, size=(651,))

# test_dataset = Dataset(test,fake_labels)

# train_total_loader = torch.utils.data.DataLoader(dataset=train_total_dataset, 
#                                            batch_size=64, 
#                                            shuffle=True)

# test_loader = torch.utils.data.DataLoader(dataset=test_dataset, 
#                                           batch_size=64, 
#                                           shuffle=False)


# In[31]:



# model = OptimizedNN().to(device)

# loss_function = nn.CrossEntropyLoss()
# optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
# #acctrain4, loss_train4, acctest4, loss_test4= train_val_NN(model, train_total_loader, test_loader, loss_function, optimizer,40)
# acctrain, loss_total, accval, loss_totalval= train_val_NN_normal(model, train_total_loader, validation_loader, loss_function, optimizer,40)
# acctrain[39]


# In[33]:


# plt.plot(loss_total)
# plt.title('experiment 4: entire training set loss')
# plt.grid(True)
# plt.ylabel('loss')
# plt.xlabel('epochs')


# In[ ]:




